<?php 
require_once KAMELEON_PLUGIN_PATH.'includes/widgets/recent-posts.php';
require_once KAMELEON_PLUGIN_PATH.'includes/widgets/recent-portfolio.php';
require_once KAMELEON_PLUGIN_PATH.'includes/widgets/social-links.php';
?>